export function Input(props) {
  return <input {...props} className="w-full border rounded p-2" />;
}